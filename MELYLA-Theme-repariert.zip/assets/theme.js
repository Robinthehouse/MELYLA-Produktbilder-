/* ============================================
   MELYLA Shopify Theme — theme.js
   ============================================ */

document.addEventListener('DOMContentLoaded', function () {

  // ── Header scroll shadow ──────────────────
  const header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 20);
    }, { passive: true });
  }

  // ── Mobile menu ───────────────────────────
  const menuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => {
      const open = mobileMenu.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', open);
      mobileMenu.setAttribute('aria-hidden', !open);
    });
  }

  // ── Dropdown hover (desktop) ──────────────
  document.querySelectorAll('.header__dropdown-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
      const expanded = trigger.getAttribute('aria-expanded') === 'true';
      trigger.setAttribute('aria-expanded', !expanded);
    });
    // Close on outside click
    document.addEventListener('click', (e) => {
      if (!trigger.closest('.header__dropdown').contains(e.target)) {
        trigger.setAttribute('aria-expanded', 'false');
      }
    });
  });

  // ── Cart drawer ───────────────────────────
  const cartBtn = document.getElementById('cart-btn');
  const cartDrawer = document.getElementById('cart-drawer');
  const cartClose = document.getElementById('cart-close');
  const cartOverlay = document.getElementById('cart-overlay');

  function openCart() {
    if (!cartDrawer) return;
    cartDrawer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    loadCartDrawer();
  }

  function closeCart() {
    if (!cartDrawer) return;
    cartDrawer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  if (cartBtn) cartBtn.addEventListener('click', openCart);
  if (cartClose) cartClose.addEventListener('click', closeCart);
  if (cartOverlay) cartOverlay.addEventListener('click', closeCart);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeCart();
  });

  // ── Load cart drawer content ──────────────
  async function loadCartDrawer() {
    const body = document.getElementById('cart-drawer-body');
    const footer = document.getElementById('cart-drawer-footer');
    const totalEl = document.getElementById('cart-total-price');
    if (!body) return;

    try {
      const res = await fetch('/cart.js');
      const cart = await res.json();

      if (cart.item_count === 0) {
        body.innerHTML = '<div class="cart-drawer__empty"><p>Dein Warenkorb ist leer.</p><a href="/collections/all" class="btn btn-cta" style="margin-top:1rem">Jetzt einkaufen</a></div>';
        if (footer) footer.style.display = 'none';
        return;
      }

      body.innerHTML = cart.items.map(item => `
        <div class="cart-drawer__item">
          <img src="${item.image}" alt="${escapeHtml(item.title)}" class="cart-drawer__item-img" width="64" height="52">
          <div>
            <p class="cart-drawer__item-title">${escapeHtml(item.product_title)}</p>
            ${item.variant_title && item.variant_title !== 'Default Title' ? `<p style="font-size:0.75rem;color:var(--muted)">${escapeHtml(item.variant_title)}</p>` : ''}
            <p class="cart-drawer__item-price">Menge: ${item.quantity} · ${formatMoney(item.final_price)}</p>
          </div>
        </div>
      `).join('');

      if (totalEl) totalEl.textContent = formatMoney(cart.total_price);
      if (footer) footer.style.display = 'flex';

    } catch (e) {
      body.innerHTML = '<div class="cart-drawer__empty"><p>Fehler beim Laden des Warenkorbs.</p></div>';
    }
  }

  // ── Update cart count badge ───────────────
  async function updateCartCount() {
    try {
      const res = await fetch('/cart.js');
      const cart = await res.json();
      const countEl = document.getElementById('cart-count');
      if (countEl) {
        countEl.textContent = cart.item_count;
        countEl.style.display = cart.item_count > 0 ? 'flex' : 'none';
      }
    } catch (e) {}
  }

  updateCartCount();

  // ── Add to Cart (AJAX) ────────────────────
  const productForm = document.getElementById('product-form');
  if (productForm) {
    productForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = document.getElementById('add-to-cart-btn');
      const variantId = document.getElementById('variant-id')?.value;
      if (!btn || !variantId) return;

      const originalHTML = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<svg class="spin" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="8" stroke="white" stroke-width="2" stroke-dasharray="25 50"/></svg> Wird hinzugefügt…';

      try {
        const res = await fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({ id: parseInt(variantId), quantity: 1 })
        });

        if (res.ok) {
          btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M4 10l5 5 7-8" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Im Warenkorb!';
          btn.style.background = '#22c55e';
          await updateCartCount();
          openCart();
          setTimeout(() => {
            btn.innerHTML = originalHTML;
            btn.style.background = '';
            btn.disabled = false;
          }, 2500);
        } else {
          throw new Error('Add to cart failed');
        }
      } catch (err) {
        btn.innerHTML = 'Fehler — bitte erneut versuchen';
        btn.style.background = '#ef4444';
        setTimeout(() => {
          btn.innerHTML = originalHTML;
          btn.style.background = '';
          btn.disabled = false;
        }, 2000);
      }
    });
  }

  // ── Scroll reveal animation ───────────────
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const style = document.createElement('style');
    style.textContent = '.reveal { opacity: 0; transform: translateY(20px); transition: opacity 0.6s ease, transform 0.6s ease; } .reveal.visible { opacity: 1; transform: none; }';
    document.head.appendChild(style);

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.product-card, .testimonial-card, .trust-badge, .section-heading').forEach(el => {
      el.classList.add('reveal');
      observer.observe(el);
    });
  }

  // ── CSS animation for spinner ─────────────
  const spinStyle = document.createElement('style');
  spinStyle.textContent = '@keyframes spin { to { transform: rotate(360deg); } } .spin { animation: spin 0.8s linear infinite; }';
  document.head.appendChild(spinStyle);

  // ── Helpers ───────────────────────────────
  function formatMoney(cents) {
    return (cents / 100).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
  }
  function escapeHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

});
